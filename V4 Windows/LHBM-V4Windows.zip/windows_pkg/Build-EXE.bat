@echo off
REM Optional: builds a standalone LHBM.exe (no Python install needed to run it).
REM Must be run ON Windows (PyInstaller cannot cross-compile from Linux/Mac).
REM Result will be in the "dist" folder as LHBM.exe

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo Python was not found in PATH. Install it from https://www.python.org/downloads/
    pause
    exit /b 1
)

python -m pip install --upgrade pyinstaller
python -m PyInstaller --onefile --windowed --name LHBM "%~dp0local_backup_manager.py"

echo.
echo Done. Find LHBM.exe inside the "dist" folder.
pause
