@echo off
REM LHBM - Local Hosted Backups Management (Windows launcher)
REM Double-click this file to run LHBM. Requires Python 3.8+ from
REM https://www.python.org/downloads/ with the "tcl/tk and IDLE" option
REM checked during install (it's checked by default).

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo Python was not found in PATH.
    echo Please install Python from https://www.python.org/downloads/
    echo and make sure "Add python.exe to PATH" is checked during install.
    pause
    exit /b 1
)

python "%~dp0local_backup_manager.py"
if %errorlevel% neq 0 (
    echo.
    echo LHBM exited with an error. See the message above.
    pause
)
