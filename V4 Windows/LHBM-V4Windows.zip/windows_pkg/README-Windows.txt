LHBM - Local Hosted Backups Management (Windows)
==================================================

Requirements
------------
- Python 3.8 or newer from https://www.python.org/downloads/
  During install, make sure these are checked (they're checked by
  default in the official installer):
    [x] Add python.exe to PATH
    [x] tcl/tk and IDLE   (this is what provides Tkinter, the GUI toolkit)

Running LHBM
------------
Option A - just run it:
    Double-click "Run-LHBM.bat"

Option B - from a command prompt:
    python local_backup_manager.py

Optional: build a standalone .exe
----------------------------------
If you'd rather have a single LHBM.exe that runs without a separate
Python install on the machine you copy it to, double-click
"Build-EXE.bat". This must be run on a Windows machine (PyInstaller
can't cross-build a Windows .exe from Linux/Mac). It downloads
PyInstaller via pip and produces dist\LHBM.exe.

Where LHBM stores its data
---------------------------
- Job configuration : %APPDATA%\LHBM\config.json
- Checksum cache     : %APPDATA%\LHBM\checksum_cache.json
- Backups themselves go wherever you set as each job's "destination"
  folder, inside a "zips" subfolder there - not under %APPDATA%.

Notes
-----
- No external Python packages are required - LHBM only uses the
  Python standard library + Tkinter.
- This is the same local_backup_manager.py used on Linux/Mac; the app
  detects Windows automatically (e.g. "Open folder" after Extract uses
  Windows Explorer, config path uses %APPDATA%).
